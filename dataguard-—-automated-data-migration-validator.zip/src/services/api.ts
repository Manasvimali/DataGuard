import {
  DatabaseConnectionConfig,
  ValidationCheckSelection,
  ValidationRunDetail,
  ValidationRunSummary,
  ValidationIssue,
  ConnectionTestResult,
  AiExplainResponse,
  DiscoveredTable,
} from '../types';

export const api = {
  async testConnection(config: DatabaseConnectionConfig): Promise<ConnectionTestResult> {
    const res = await fetch('/api/connections/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Failed to connect to database');
    }
    return res.json();
  },

  async discoverTables(
    sourceConfig: DatabaseConnectionConfig,
    targetConfig: DatabaseConnectionConfig
  ): Promise<{ success: boolean; discoveredTables: DiscoveredTable[] }> {
    const res = await fetch('/api/connections/discover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceConfig, targetConfig }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Failed to discover tables');
    }
    return res.json();
  },

  async startValidation(
    sourceConfig: DatabaseConnectionConfig,
    targetConfig: DatabaseConnectionConfig,
    options: ValidationCheckSelection
  ): Promise<ValidationRunDetail> {
    const res = await fetch('/api/validation/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceConfig, targetConfig, options }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Validation execution failed');
    }
    return res.json();
  },

  async getHistory(): Promise<ValidationRunSummary[]> {
    const res = await fetch('/api/validation/history');
    if (!res.ok) {
      throw new Error('Failed to fetch validation history');
    }
    return res.json();
  },

  async getRunDetail(id: string): Promise<ValidationRunDetail> {
    const res = await fetch(`/api/validation/${id}`);
    if (!res.ok) {
      throw new Error('Failed to load validation run');
    }
    return res.json();
  },

  async getLatestRunDetail(): Promise<ValidationRunDetail> {
    const res = await fetch('/api/validation/latest/detail');
    if (!res.ok) {
      throw new Error('Failed to load latest validation run');
    }
    return res.json();
  },

  async quickRun(options?: ValidationCheckSelection): Promise<ValidationRunDetail> {
    const res = await fetch('/api/validation/quick-run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: 'demo', options }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Quick validation execution failed');
    }
    return res.json();
  },

  async sendChatMessage(
    messages: { role: 'user' | 'assistant' | 'model'; content: string }[],
    context?: any,
    model?: string
  ): Promise<{ text: string; provider: 'gemini' | 'context-engine' }> {
    const res = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, context, model }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to communicate with AI Copilot');
    }
    return res.json();
  },

  async explainIssue(issue: ValidationIssue): Promise<AiExplainResponse> {
    const res = await fetch('/api/ai/explain', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ issue }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to generate explanation');
    }
    return res.json();
  },
};
